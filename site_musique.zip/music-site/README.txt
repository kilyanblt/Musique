# Site musique — Mode d'emploi rapide

## Modifier les textes
- Ouvre `index.html` et remplace **Ton Nom d'Artiste** par ton blaze.
- Mets tes vraies dates dans la section `#tour`.
- Mets ton e-mail dans le formulaire `mailto:` ou utilise Formspree/Netlify Forms.

## Ajouter des sons
- Place tes `.mp3` ou `.wav` dans `assets/` puis duplique le bloc `<article class="track">`.
- Change `src="assets/demo_track.wav"` par ton fichier.

## Intégrer Spotify/Apple/SoundCloud
- Remplace les liens par les vrais, ou colle un iframe d'intégration officiel.

## Mettre en ligne rapidement
- **GitHub Pages** : uploade le dossier dans un repo et active Pages.
- **Netlify** : glisse-dépose le dossier, domaine gratuit.
- **Vercel** : même principe, gratuit.

## Personnaliser les couleurs
- Ouvre `style.css` et modifie les variables dans `:root` (ex: `--primary`).

Bonne scène !
